package com.example.factorial.service;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class FactorialService {
    public List<Long> calculateFactorials(int n) {
        List<Long> result = new ArrayList<>();
        long factorial = 1;
        for (int i = 1; i <= n; i++) {
            factorial *= i;
            result.add(factorial);
        }
        return result;
    }
}