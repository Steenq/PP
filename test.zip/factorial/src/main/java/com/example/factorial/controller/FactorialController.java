package com.example.factorial.controller;

import com.example.factorial.service.FactorialService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/api/factorials")
public class FactorialController {
    private final FactorialService factorialService;

    public FactorialController(FactorialService factorialService) {
        this.factorialService = factorialService;
    }

    @GetMapping("/{n}")
    public ResponseEntity<List<Long>> getFactorials(@PathVariable int n) {
        if (n <= 0) {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(factorialService.calculateFactorials(n));
    }
}