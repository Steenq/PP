package com.example.factorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
