package com.example.factorial.service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FactorialServiceTest {

    private final FactorialService factorialService = new FactorialService();

    @Test
    void calculateFactorials_validInput() {
        List<Long> result = factorialService.calculateFactorials(5);
        assertEquals(List.of(1L, 2L, 6L, 24L, 120L), result);
    }

    @Test
    void calculateFactorials_zeroInput() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            factorialService.calculateFactorials(0);
        });
        assertEquals("Input number must be a positive integer.", exception.getMessage());
    }

    @Test
    void calculateFactorials_negativeInput() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            factorialService.calculateFactorials(-3);
        });
        assertEquals("Input number must be a positive integer.", exception.getMessage());
    }
}
